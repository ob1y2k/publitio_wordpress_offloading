var searchData=
[
  ['badjsonresponse',['BadJSONResponse',['../classPublitio_1_1BadJSONResponse.html',1,'Publitio']]]
];
